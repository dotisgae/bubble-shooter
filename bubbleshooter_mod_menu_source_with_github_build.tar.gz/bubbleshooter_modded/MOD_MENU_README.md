# Bubble Shooter mod menu build

This source tree adds a single-player in-game menu to the Flutter/Flame Bubble Shooter project.

Features:
- Bubble ESP: cyan outlines and color/row/column labels for bubbles in the live grid.
- Bubble tracers: lines from the launcher to each bubble.
- Auto-hit: periodically evaluates upward firing angles, predicts the landing cell using the game's grid/collision helpers, and fires toward a high-scoring color match.

Build:
1. Open this folder in Android Studio with the Flutter and Dart plugins installed.
2. Ensure the Flutter SDK version satisfies the project's pubspec.yaml (`sdk: ^3.12.2`).
3. Run `flutter pub get`.
4. Run on an Android device or emulator.

The original `.pub-cache`, `.dart_tool`, and machine-specific `local.properties` were omitted; Flutter regenerates its package/tool metadata locally.

Note: I could inspect and modify the source, but this environment does not have the Flutter/Dart SDK installed, so I could not run `flutter analyze` or build an APK here.
