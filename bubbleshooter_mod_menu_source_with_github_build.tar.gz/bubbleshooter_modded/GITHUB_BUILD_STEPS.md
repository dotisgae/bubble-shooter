# Build an APK with GitHub Actions (phone-friendly)

This repository includes `.github/workflows/build-apk.yml`. It builds a **debug APK** and uploads it as a downloadable workflow artifact. No signing secrets are needed for a debug build.

## Option A — Upload the project folder to a GitHub repository

1. Create a new repository on GitHub.
2. Upload the contents of this project folder (including the hidden `.github` folder) to the repository's default branch.
3. Open the repository's **Actions** tab.
4. Select **Build Bubble Shooter APK** in the workflow list.
5. Tap **Run workflow**, keep the default branch selected, and tap the green **Run workflow** button.
6. Wait for the run to finish successfully.
7. Open the completed run and download the `bubble-shooter-debug-apk` artifact.
8. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.
9. Open the APK on your Android device and approve installation if Android asks.

## Option B — Upload only the archive (easier from a phone)

1. Create a new GitHub repository.
2. At the repository root, upload the file `bubbleshooter_mod_menu_source.tar.gz`.
3. In GitHub, choose **Add file → Create new file**.
4. Set the filename to `.github/workflows/build-apk.yml`.
5. Paste the contents of the separate `build-apk.yml` file supplied with this package, then commit the file to the default branch.
6. Open **Actions → Build Bubble Shooter APK → Run workflow**.
7. When the run finishes, download the `bubble-shooter-debug-apk` artifact and extract its ZIP to get `app-debug.apk`.

## Notes

- The workflow deliberately builds a debug APK, so it does not need a keystore or GitHub secrets.
- The first build can take several minutes while GitHub downloads Flutter and Android build dependencies.
- This workflow can report source-code or dependency errors. If it fails, open the failed run, expand the first red step, and share the error log.
- The archive's machine-specific `android/local.properties` is removed during the cloud build.
